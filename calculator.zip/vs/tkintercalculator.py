#importing 
import tkinter as tk
#gui interaction
root = tk.Tk()
root.title("Simple Calculator")
root.geometry("300x400")
root.resizable(False, False)
#adding inputs
entry = tk.Entry(root, font=("Arial", 20), justify="right", bd=5)
entry.pack(fill="both", padx=10, pady=10)
#function 
def press(value):
    entry.insert(tk.END, value)

def clear():
    entry.delete(0, tk.END)

def calculate():
    try:
        result = eval(entry.get())
        entry.delete(0, tk.END)
        entry.insert(0, result)
    except:
        entry.delete(0, tk.END)
        entry.insert(0, "Error")

#button and operators
frame = tk.Frame(root)
frame.pack()

buttons = [
    ("7", 1, 0), ("8", 1, 1), ("9", 1, 2), ("/", 1, 3),
    ("4", 2, 0), ("5", 2, 1), ("6", 2, 2), ("*", 2, 3),
    ("1", 3, 0), ("2", 3, 1), ("3", 3, 2), ("-", 3, 3),
    ("0", 4, 0), (".", 4, 1), ("=", 4, 2), ("+", 4, 3),
]

for text, row, col in buttons:
    if text == "=":
        btn = tk.Button(frame, text=text, width=5, height=2,
                        font=("Arial", 14), command=calculate)
    else:
        btn = tk.Button(frame, text=text, width=5, height=2,
                        font=("Arial", 14),
                        command=lambda t=text: press(t))
    btn.grid(row=row, column=col, padx=5, pady=5)
#clear button
clear_btn = tk.Button(root, text="Clear", font=("Arial", 14), command=clear)
clear_btn.pack(fill="both", padx=10, pady=10)
#looping
root.mainloop()

